// Connect to the WebSocket server
var socket = new WebSocket("ws://" + location.hostname + ":81/");

// Send a message to the server when the connection is established
socket.onopen = function() {
	console.log("Connected to server");
};

// Log an error message if the connection could not be established
socket.onerror = function() {
	console.log("Error connecting to server");
};

// Send a message to the server when the connection is closed
socket.onclose = function() {
	console.log("Disconnected from server");
};

// Define functions to send messages to the server
function move_forward() {
	socket.send("forward");
}

function move_backward() {
	socket.send("backward");
}

function move_left() {
	socket.send("left");
}

function move_right() {
	socket.send("right");
}

function stop() {
	socket.send("stop");
}
