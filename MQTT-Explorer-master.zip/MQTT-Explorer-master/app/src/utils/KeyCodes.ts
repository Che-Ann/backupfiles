export enum KeyCodes {
  backspace = 8,
  tab = 9,
  enter = 13,
  escape = 27,
  arrow_left = 37,
  arrow_up = 38,
  arrow_right = 39,
  arrow_down = 40,
  delete = 46,
}
