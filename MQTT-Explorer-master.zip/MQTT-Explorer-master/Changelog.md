# 0.2.3

  - Highlight differences in the last received message with a "diff" view
  - Magnify app content with "Ctrl +", "Ctrl -", "Ctrl 0"
  - Make user interactions more predictable by removing "select topic on mouse over"
  - Add "Quick Preview" setting, to enable topic selection on mouse over
  - Add JSON formatter
  - Show error when connection to the mqtt broker is lost
  - Fix bug where mqtt explorer resets the tree after a reconnect
  - Fix MQTT-Client id

# 0.2.0
