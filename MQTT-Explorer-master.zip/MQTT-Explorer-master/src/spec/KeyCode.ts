export const Control = '\uE009'
export const Unknown = '\uE000'
export const Plus = '\uE025'
