export interface Hashable {
  hash(): string
}
