export enum Decoder {
    NONE,
    SPARKPLUG
}
