export interface Destroyable {
  destroy(): void
}
