export interface CallbackStore {
    wrappedCallback: any;
    callback: any;
}
